# SPDX-FileCopyrightText: 2023-present Don Caldwell <dfwcnj@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.12"
